package com.arshad.clovermobileapp.data
/*
* This is enum class for API calling status
*
* */
enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}